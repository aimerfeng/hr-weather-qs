#!/bin/bash
python3 -m terminal.main
